package Assignment4;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class maingui extends JFrame {

	private JPanel contentPane;
    String str1;
    String str2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					maingui frame = new maingui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	
	public maingui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(50, 31, 142, 23);
		contentPane.add(textArea);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 79, 414, 161);
		contentPane.add(scrollPane);
		
		JTextArea textArea_1 = new JTextArea();
		scrollPane.setViewportView(textArea_1);
		textArea_1.setEditable(false);
		
				
		JButton btnSearch = new JButton("search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea_1.setText("");
				str1=textArea.getText();
				if(!str1.isEmpty()){
              
		            String array[][] = new String [30][30];
					int i=0;
				    int num=0;
				    
				SequenceQuery query=new SequenceQuery();
				String uri="jdbc:mysql";
				String id="127.0.01:3306";
				String datasorce="my_schema";
				String password="123456";
				String tableName="2014302580175_professor_info";
				query.setUri(uri);
				query.setId(id);
				query.setDatasourceName(datasorce);
				query.setPassword(password);
				query.setTableName(tableName);
				
				str1=textArea.getText();
				ArrayList<StringBuffer>result=query.getQueryResult();
				for(StringBuffer str:result)
				{
					str2=str.toString();
					num=Match.match(str1,str2);
					if(num!=0)
					{
					array[num-1][i]=str2;
					i++;
					}	
				}
				for(int i2=0;i2<=num;i2++)
				{
					for(int i3=0;i3<=i;i3++)
					{
						if(array[num-i2][i3]!=null)
						{ textArea_1.append(array[num-i2][i3]+"\n\n");}
				    }
				}
			}
		}
			
		});
		btnSearch.setBounds(263, 31, 93, 23);
		contentPane.add(btnSearch);
		

		

	}
}
