package Assignment4;

public class Match {
	 public static int match(String str1,String str2){
        int index=-1,count=0;
		for(int i=0;i<str2.length();i++)
		if((str2.indexOf(str1,index+1))!=-1){
		index=str2.indexOf(str1,index+1);
		count++;
		}
		return count;
	}

}
