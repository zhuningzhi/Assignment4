package Assignment4;
//��Ϊ����java������������Ƶڶ��桷��p351ҳʵ��java����
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Query {
	String uri="";
	String id="";
	String datasourceName ="";
	String password ="";
	String tableName="";
	String SQL;
	ArrayList<StringBuffer>queryResult;
	public Query(){
		try {
			Class.forName("com.mysql.jdbc.Driver");} 
		catch (ClassNotFoundException e) {
			e.printStackTrace();}
	}
	public void setUri(String s){uri=s;}
	public void setId(String s){id=s;}
	public void setDatasourceName(String s){datasourceName=s;}
	public void setPassword(String s){password=s;}
	public void setTableName(String s){tableName=s;}
	public void setSQL(String SQL){this.SQL=SQL;}
	
	public ArrayList<StringBuffer>getQueryResult(){
		queryResult=new ArrayList<StringBuffer>();
		Connection con;
		Statement sql;
		ResultSet rs;
		try{
			String url=uri+"://"+id+"/"+datasourceName+"?"+ "user=root&password="+password;
			con =DriverManager.getConnection(url);
			DatabaseMetaData metadata =con.getMetaData();
			ResultSet rs1=metadata.getColumns(null, null, tableName, null);
			int num=0;
			while(rs1.next()){
				num++;
			}
			sql=con.createStatement();
			rs=sql.executeQuery(SQL);
			while(rs.next()){
				StringBuffer record=new StringBuffer();
				for(int k=1;k<=num;k++){
					record.append(" "+rs.getString(k)+" ");
				}
				queryResult.add(record);
			}
			con.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return queryResult;
	}
		
}


