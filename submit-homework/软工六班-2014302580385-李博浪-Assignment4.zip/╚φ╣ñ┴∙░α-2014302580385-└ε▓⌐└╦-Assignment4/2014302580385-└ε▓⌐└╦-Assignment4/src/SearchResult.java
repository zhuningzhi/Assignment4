
public class SearchResult
{
	private ProfessorInfo pi;
	private double tf;
	public ProfessorInfo getPi()
	{
		return pi;
	}
	public void setPi(ProfessorInfo pi)
	{
		this.pi = pi;
	}
	public double getTf()
	{
		return tf;
	}
	public void setTf(double tf)
	{
		this.tf = tf;
	}
}
