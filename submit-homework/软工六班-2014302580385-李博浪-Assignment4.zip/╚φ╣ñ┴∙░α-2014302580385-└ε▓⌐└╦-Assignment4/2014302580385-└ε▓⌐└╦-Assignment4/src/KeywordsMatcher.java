import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;


public class KeywordsMatcher
{
	private ArrayList<String> keywordsList;
	private ArrayList<SearchResult> SearchResultList;
	private ArrayList<String> stopWords;
	public KeywordsMatcher()
	{
		//ȥ�������ֶ�
		String[] tempStopWords={"of","the","a","an"};
		stopWords=new ArrayList<String>(Arrays.asList(tempStopWords));
		
		//��ȡ�������
		DataReader dataReader=new DataReader();
		ArrayList<ProfessorInfo> tempInfoList=dataReader.read();
		SearchResultList=new ArrayList<SearchResult>();
		
		for(ProfessorInfo temp:tempInfoList)
		{
			SearchResult sr=new SearchResult();
			sr.setPi(temp);
			//sr.setTf(0);
			SearchResultList.add(sr);
			
		}
	}
	
	//��ȡ�ؼ���
	public void fetchKeywords(String text)
	{
		String[] tempString=text.split("\\s");
		keywordsList=new ArrayList<String>(Arrays.asList(tempString));
	}
	
	//����tfֵ
	public void calTf()
	{
			
		for(SearchResult tempSearchResult:SearchResultList)
		{
				
			String[] tempSplitWords;
			double tf=0;
			for(String tempKey:keywordsList)
			{
					//�ж��Ƿ�����ֹ��
				Boolean isStopWord=false;
				for(String tempStopWord:stopWords)
				{
					if(tempStopWord.equals(tempKey))
						isStopWord=true;
				}
					
				if(isStopWord==true) continue;
					
					
				//ƥ������
				tempSplitWords=tempSearchResult.getPi().getName().split("\\s");
				for(String tempNameSplit:tempSplitWords)
				{
					if(tempNameSplit.equals(tempKey))
						tf+=0.6;
					
				}
					
				//ƥ���������
				tempSplitWords=tempSearchResult.getPi().getEducationBackground().split("\\s");
				for(String tempEducationBackground:tempSplitWords)
				{
					if(tempEducationBackground.equals(tempKey))
						tf+=0.5;
				
				}
				
				//ƥ���о�����
				tempSplitWords=tempSearchResult.getPi().getResearchInterests().split("\\s");
				for(String tempResearchInterests:tempSplitWords)
				{
					if(tempResearchInterests.equals(tempKey))
						tf+=0.5;			
				}
				
			
				//����tfֵ
				tempSearchResult.setTf(tf);		
			}
		}//end for(SearchResult tempSearchResult:SearchResultList)
			
	
	}//end calTF()
	
	//����
	public ArrayList<SearchResult> sort()
	{
		SearchResultComparator src=new SearchResultComparator();
		Collections.sort(SearchResultList,src);
		return SearchResultList;
	}
	
	class SearchResultComparator implements Comparator<SearchResult>
	{

		@Override
		public int compare(SearchResult sr1, SearchResult sr2)
		{
			
			if(sr1.getTf()>sr2.getTf())
				return 1;
			else if(sr1.getTf()<sr2.getTf())
				return -1;
			
				return 0;
		}	
		
	}
	
	

}
