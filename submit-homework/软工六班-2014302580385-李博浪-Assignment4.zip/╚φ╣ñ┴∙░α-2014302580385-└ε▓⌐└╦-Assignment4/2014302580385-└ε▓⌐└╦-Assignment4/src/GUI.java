import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.*;


public class GUI
{
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				JFrame frame=new GUIFrame();
				frame.setVisible(true);
				frame.setTitle("��������");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
	}
}

class GUIFrame extends JFrame
{
	private static final int WIDTH=400;
	private static final int HEIGHT=400;
	public GUIFrame()
	{
		setSize(WIDTH,HEIGHT);
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		setLocation(screenSize.width/2-WIDTH/2,screenSize.height/2-HEIGHT/2);
		add(new GUIPanel());
	}
}

class GUIPanel extends JPanel
{
	private JButton ensure;
	private JTextField input;
	private JTextArea output;
	private JScrollPane scrollpane;
	private String keywords;
	private KeywordsMatcher keymat;
	
	public GUIPanel()
	{
		keymat=new KeywordsMatcher();
		
		this.setLayout(null);
		ensure=new JButton("����");
		input=new JTextField();
		output=new JTextArea();
		scrollpane=new JScrollPane(output);
		
		ensure.addActionListener(new EnsureAciton());
		
		output.setLineWrap(true);
		
		add(ensure);
		add(input);
		add(scrollpane);
		
		input.setBounds(10,10,300,30);
		ensure.setBounds(320,10,60,30);
		scrollpane.setBounds(10,50,360,300);
		
	}
	class EnsureAciton extends AbstractAction
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			output.setText("");
			keywords=input.getText().trim();
			
			keymat.fetchKeywords(keywords);
			keymat.calTf();
			ArrayList<SearchResult> SearchResultList=keymat.sort();
			for(SearchResult tempSearchResult:SearchResultList)
			{
				
				if(tempSearchResult.getTf()>0)
				{
					ProfessorInfo tempInfo=tempSearchResult.getPi();
					String name=tempInfo.getName();
					String educationBackground=tempInfo.getEducationBackground();
					String researchInterests=tempInfo.getResearchInterests();
					String email=tempInfo.getEmail();
					String phone=tempInfo.getPhone();
					
					String proInfo="Name:"+name+"\n"+"EducationBackground:"+educationBackground+"\n"+"ResearchInterests"+researchInterests+"\n"
							+"email:"+email+"\n"+"phone:"+phone+"\n\n\n";
					output.append(proInfo);
					
				}
			}
			
			
			
		}
		
	}
}
