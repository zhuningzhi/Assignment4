import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class DataReader
{
	private String url="jdbc:mysql://127.0.0.1:3306/new_schema?user=root&password=lbl730911";
	private String sql="SELECT * FROM 2014302580385_professor_info;";
	public Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url);
			System.out.println("ע�������ɹ�");
			return conn;
		} catch (ClassNotFoundException | SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			System.out.println("ע������ʧ��");
			return null;
		}
	
	}
	
	public ArrayList<ProfessorInfo> read()
	{
		ArrayList<ProfessorInfo> proList=new ArrayList<ProfessorInfo>();
		Connection conn=this.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=conn.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next())
			{
				ProfessorInfo temp=new ProfessorInfo();
				temp.setName(rs.getString(1).toLowerCase());
				temp.setEducationBackground(rs.getString(2).toLowerCase());
				temp.setResearchInterests(rs.getString(3).toLowerCase());
				temp.setEmail(rs.getString(4).toLowerCase());
				temp.setPhone(rs.getString(5).toLowerCase());
				proList.add(temp);				
			}
			return proList;
			
		} catch (SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			return null;
		}finally
		{
			try
			{
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			
			
		}
		
		
	}
}
