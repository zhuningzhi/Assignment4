
public class ProfessorInformation {
	private String m_name;
	private String m_email;
	private String m_phone;
	private String m_educationBackground;
	private String m_researchInterest;
	//��Ա����
	//������
	public ProfessorInformation(String name,String email,String phone,String educationBackground,String researchInterest){
		m_educationBackground=educationBackground;
		m_email=email;
		m_phone=phone;
		m_researchInterest=researchInterest;
		m_name=name;
	}
	//��ȡname������
	public String getname(){
		return m_name;
	}
	public String getEducationBackground(){
		return m_educationBackground;
	}
	public String getEmail(){
		return m_email;
	}
	public String getResearchInterest(){
		return m_researchInterest;
	}
	public String getPhone(){
		return m_phone;
	}
	//���ԣ������Ϣ
	public void outToConsole(){
		System.out.println(m_name);
		System.out.println(m_phone);
		System.out.println(m_email);
		System.out.println(m_researchInterest);
		System.out.println(m_educationBackground);
		System.out.println("\n\n\n");
	}
	
}
