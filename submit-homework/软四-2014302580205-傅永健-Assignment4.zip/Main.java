import java.sql.SQLException;
import java.util.ArrayList;


public class Main {
	public void main() throws ClassNotFoundException, SQLException{
		KeyWordMatcher match=new KeyWordMatcher("computer science");
		match.outToConsole();
	}
}
