
public class StaticString {
	static public String URL=new String("jdbc:mysql://localhost:3306/teacher");
	static public String USER_NAME=new String("root");
	static public String PASSWORD=new String("yongjian");
	static public String INSTRUCTION=new String("select * from professor_info");
}
