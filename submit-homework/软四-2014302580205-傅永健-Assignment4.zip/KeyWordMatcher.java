import java.io.Reader;
import java.sql.SQLException;
import java.util.ArrayList;


public class KeyWordMatcher {
	private SearchResult [] m_result;
	private String [] m_keyWord;
	private DataReader m_reader;
	
	//��Ա����
	//������
	public KeyWordMatcher(String text) throws ClassNotFoundException, SQLException{
		m_keyWord=text.split(" ");
		m_reader=new DataReader();
		ArrayList<ProfessorInformation> data=m_reader.getData();
		m_result=new SearchResult[data.size()];
		for(int i=0;i<data.size();i++){
			m_result[i]=new SearchResult(data.get(i), calculateTF(data.get(i)));
		}
		sortByTF();
	}
	//��ȡ���
	public ArrayList<SearchResult> getSearchResults(){
		ArrayList<SearchResult> result=new ArrayList<SearchResult>();
		for(int i=0;i<m_result.length;i++){
			result.add(m_result[i]);
		}
		
		return result;
	}
	//���ԣ����
	public void outToConsole(){
		for(int i=0;m_result[i].getTF()!=0&&i<m_result.length;i++){
			m_result[i].getData().outToConsole();
		}
	}
	//���ߺ���
	//����tf
	private double calculateTF(ProfessorInformation information){
		double tf=0;
		Boolean notInBackGroundOnly=false;
		String [] name=information.getname().split(" ");
		String [] email=information.getEmail().split(" ");
		String [] phone=information.getPhone().split(" ");
		String [] background=information.getEducationBackground().split(" ");
		String [] interest=information.getResearchInterest().split("[ \\n]");
		
		double numOfWord=name.length+email.length+phone.length+background.length+interest.length;
		int countMatch=countMatch(name)+countMatch(email)+countMatch(phone)+countMatch(interest);
		countMatch*=5;
		countMatch+=countMatch(background);
		tf=countMatch/numOfWord;
		return tf;
	}
	//����ƥ�����
	private int countMatch(String []contain){
		int count =0;
		for(int i=0;i<m_keyWord.length;i++){
			for(int j=0;j<contain.length;j++){
				if(m_keyWord[i].equalsIgnoreCase(contain[j])){
					count++;
				}
			}
		}
		return count;
	}
	//����
	private void sortByTF(){
		for(int i=0;i<m_result.length-1;i++){
			for(int j=i+1;j<m_result.length;j++){
				if(m_result[i].getTF()<m_result[j].getTF()){
					SearchResult temp=m_result[i];
					m_result[i]=m_result[j];
					m_result[j]=temp;
				}
			}
		}
	}
}
