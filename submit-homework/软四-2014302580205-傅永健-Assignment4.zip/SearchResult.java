import java.io.ObjectInputStream.GetField;


public class SearchResult {
	private ProfessorInformation m_data;
	private double m_tf;
	//��Ա����
	//���캯��
	public SearchResult(ProfessorInformation data,double tf){
		m_data=data;
		m_tf=tf;
	}
	//��ȡtfֵ��dataֵ
	public double getTF(){
		return m_tf;
	}
	public ProfessorInformation getData(){
		return m_data;
	}
}
