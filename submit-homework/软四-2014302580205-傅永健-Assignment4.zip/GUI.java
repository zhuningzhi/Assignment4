import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.xml.bind.attachment.AttachmentMarshaller;


public class GUI {
	private JFrame m_frame;
	private JTextArea m_textOut;
	private JTextArea m_textIn;
	private JScrollPane m_scrollPane;
	private JButton m_button;
	
	static public void main(String []argc){
		GUI gui=new GUI();
	}
	
	//��Ա����
	//���캯��
	public GUI(){
		Instantiate();
		attach();
		
	}
	//���ߺ���
	//ʵ����
	private void Instantiate(){
		m_frame=new JFrame();
		m_frame.setSize(800, 900);
		m_frame.setTitle("������");
		m_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		m_textIn=new JTextArea(0, 31);
		m_textIn.setFont(new Font("΢���ź�",Font.BOLD,32));
		m_frame.add(m_textIn);
		
		m_textOut=new JTextArea(35,30);
		m_textOut.setFont(new Font("΢���ź�",Font.BOLD,24));
		m_textOut.setLineWrap(true);
		m_scrollPane=new JScrollPane(m_textOut);
		m_scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		m_frame.add(m_scrollPane);
		
		m_button=new JButton("Search");
		m_frame.add(m_button);
		
		m_frame.setLayout(getLayout());
		m_frame.setVisible(true);
	}
	//����
	private GridBagLayout getLayout(){
		GridBagLayout layout=new GridBagLayout();
		GridBagConstraints[]container=new GridBagConstraints[3];
		for(int i=0;i<3;i++){
			container[i]=new GridBagConstraints();
		}
		container[0].weightx=7;
		container[0].weighty=1;
		container[1].weightx=1;
		container[1].weighty=1;
		container[2].weightx=8;
		container[2].weighty=8;
		
		container[0].gridheight=1;
		container[0].gridwidth=7;
		container[1].gridheight=1;
		container[1].gridwidth=1;
		container[2].gridheight=8;
		container[2].gridwidth=8;
		
		container[0].fill=GridBagConstraints.BOTH;
		container[1].fill=GridBagConstraints.BOTH;
		container[2].fill=GridBagConstraints.BOTH;
		
		container[0].gridx=1;
		container[0].gridy=0;
		container[1].gridx=9;
		container[1].gridy=0;
		container[2].gridy=1;
		container[2].gridx=2;
		
		
		layout.setConstraints(m_textIn, container[0]);
		layout.setConstraints(m_button, container[1]);
		layout.setConstraints(m_scrollPane, container[2]);
		return layout;
	}
	//�󶨼����¼�
	private void attach(){
		m_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					m_textOut.setText("");
					KeyWordMatcher matcher=new KeyWordMatcher(m_textIn.getText());
					ArrayList<SearchResult> result=matcher.getSearchResults();
					int count =0;
					for(SearchResult i:result){
						
						if(i.getTF()!=0){
							m_textOut.append("Name:"+i.getData().getname()+"\n");
							m_textOut.append("Phone Number:"+i.getData().getPhone()+"\n");
							m_textOut.append("E-mail:"+i.getData().getEmail()+"\n");
							m_textOut.append("Search Interest:"+i.getData().getResearchInterest()+"\n");
							m_textOut.append("Education Background:"+i.getData().getEducationBackground()+"\n\n\n");
							count++;
						}
					}
					m_textIn.setText("");
					m_textOut.append(String.format("��%d����¼", count));
				} catch (ClassNotFoundException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				} catch (SQLException e2) {
					// TODO �Զ����ɵ� catch ��
					e2.printStackTrace();
				}
				
				
			}
		});
	}
}
