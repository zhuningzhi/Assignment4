import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Jason_Wei on 2015/11/9.
 */
public class StringComparator implements Comparator<String>
{
    @Override
    public int compare(String s1, String s2)
    {
        if (s1.contains(SearchEngine.searchContent) || s2.contains(SearchEngine.searchContent)) SearchEngine.haveFound = true;

        Pattern pattern = Pattern.compile(SearchEngine.searchContent);
        Matcher matcher1 = pattern.matcher(s1);
        Matcher matcher2 = pattern.matcher(s2);

        int count1 = 0, count2 = 0;

        while (matcher1.find()) count1++;
        while (matcher2.find()) count2++;

        if (count1 < count2)
            return 1;
        return -1;
    }
}

