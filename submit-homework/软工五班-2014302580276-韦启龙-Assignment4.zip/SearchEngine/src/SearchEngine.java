import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

/**
 * Created by Jason_Wei on 2015/11/9.
 */
public class SearchEngine
{
    static String searchContent = "";
    static ArrayList<String> list;
    static boolean haveFound = false;

    public static void main(String[] args)
    {
        JFrame window = new JFrame("SearchEngine v0.0");

        window.setResizable(false);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500, 500);

        try
        {
            window.setIconImage(ImageIO.read(new File("resources/icon.png")));
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        window.setVisible(true);
        window.setLayout(null);

        JTextField input = new JTextField();
        window.add(input);
        input.setBounds(20, 20, 330, 35);
        input.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

        JButton button = new JButton();
        window.add(button);
        button.setBounds(370, 20, 100, 35);
        button.setText("Search");
        button.setFocusPainted(false);

        JTextArea output = new JTextArea();

        JScrollPane scrollPane = new JScrollPane(output);
        window.add(scrollPane);
        scrollPane.setBounds(20, 95, 450, 355);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

        output.setEditable(false);
        output.setText(" ");

        try
        {
            list = DBReader.readDB();
        } catch (Exception e)
        {
            e.printStackTrace();
        }

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {

                if (input.getText().equals(""))
                {
                    output.setText("Content can't be null !");
                    return;
                }
                else
                {
                    searchContent = input.getText();
                }

                list.sort(new StringComparator());

                if (!haveFound)
                {
                    output.setText("Can't find the content !");
                    return;
                }

                output.setText("");


                String searchResult = "";
                for (String s : list)
                {
                    searchResult += s + "\n" +
                            "-----------------------------------------------------" +
                            "-----------------------------------------------------\n";
                }

                output.setText(searchResult);

                output.setCaretPosition(0);

                haveFound = false;
            }
        });
    }
}

