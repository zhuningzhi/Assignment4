import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Created by Jason_Wei on 2015/11/9.
 */
public class DBReader
{
    //private static String url = "jdbc:mysql://localhost:3306/teacher_info?user=root&password=rootpwd";
    private static String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";

    public static ArrayList<String> readDB() throws Exception
    {
        ArrayList<String> list = new ArrayList<>();

        Class.forName("com.mysql.jdbc.Driver");

        Connection connection = DriverManager.getConnection(url);

        Statement sql=connection.createStatement();
        ResultSet results = sql.executeQuery("select * from 2014302580276_professor_info");

        while (results.next())
        {
            list.add(results.getString("name") + "\n" + results.getString("educationBackground") +
                    results.getString("researchInterests") + results.getString("email") + "\n" + results.getString("phone"));
        }

        return list;
    }
}

