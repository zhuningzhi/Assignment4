package cn.search;

public class ProfessorInfo {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;
	
	public ProfessorInfo(String a1,String a2,String a3,String a4,String a5){
		this.name = a1;
		this.educationBackground = a2;
		this.researchInterests = a3;
		this.email = a4;
		this.phone = a5;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEducationBackground() {
		return educationBackground;
	}
	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}
	public String getResearchInterests() {
		return researchInterests;
	}
	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
