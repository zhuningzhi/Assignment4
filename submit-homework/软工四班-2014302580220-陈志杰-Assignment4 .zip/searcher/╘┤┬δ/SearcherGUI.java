package cn.search;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.PrintStream;
import java.sql.SQLException;


public class SearcherGUI {
    String[] keywords;
	private JFrame frame;
	PrintStream printstream;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SearcherGUI window = new SearcherGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SearcherGUI() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Searcher");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(14, 13, 219, 30);
		frame.getContentPane().add(textArea);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(14, 67, 404, 175);
		textArea_1.setEditable(false);
		textArea_1.setLineWrap(true);
		frame.getContentPane().add(textArea_1);
		
		JScrollPane scroll = new JScrollPane();
		scroll.setBounds(14, 67, 404, 175);
		frame.add(scroll);
		scroll.setViewportView(textArea_1);
		
		JButton btnSearch = new JButton("search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textArea_1.setText("");
				keywords = textArea.getText().trim().split(" ");
				ProfessorInfo_get pi_g= new ProfessorInfo_get();
				try {
					pi_g.getProfessorInfoFromDatabase();
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				KeywordsMatcher km = new KeywordsMatcher(keywords);
				km.cal_TF(pi_g.getProfessorinfo());
				km.show(pi_g.getProfessorinfo());
			}
		});
		btnSearch.setBounds(280, 13, 113, 30);
		frame.getContentPane().add(btnSearch);
		
		printstream = new PrintStream(System.out){
		      public void println(String x) {
		    	textArea_1.append(x + "\n");
		    	textArea_1.setCaretPosition(textArea_1.getText().length());
		      }
		      public void print(String x){
		    	  textArea_1.append(x);
		    	  textArea_1.setCaretPosition(textArea_1.getText().length());}
		      };
		System.setOut(printstream);
	}
}
