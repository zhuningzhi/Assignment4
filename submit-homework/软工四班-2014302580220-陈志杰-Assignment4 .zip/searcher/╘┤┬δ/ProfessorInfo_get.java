package cn.search;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;



public class ProfessorInfo_get {
	private ArrayList<ProfessorInfo> professorinfo = new ArrayList<ProfessorInfo>();   //�洢�����ݿ����Ľ�����Ϣ

	public ArrayList<ProfessorInfo> getProfessorinfo() {
		return professorinfo;
	}
	 
	public void getProfessorInfoFromDatabase() throws ClassNotFoundException, SQLException{         //�����ݿ��ȡ���н�����Ϣ
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema?"  
                + "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
		Connection conn = null;
		String sql;
		try{
			 Class.forName("com.mysql.jdbc.Driver");      //����jdbc��������
			 conn = DriverManager.getConnection(url);
	         Statement stmt = conn.createStatement();
	         sql = "select * from 2014302580220_professor_info";
	         ResultSet result = stmt.executeQuery(sql);   //��ȡ���ڵ���Ϣ
	         while(result.next()){
	        	 professorinfo.add(new ProfessorInfo(
	        			 result.getString(1),result.getString(2),result.getString(3),result.getString(4),result.getString(5)));
	        	 
	         }
	    }catch(SQLException e){
	    	e.printStackTrace();
	    }finally{
	    	conn.close();
	    }
	
	}
}
