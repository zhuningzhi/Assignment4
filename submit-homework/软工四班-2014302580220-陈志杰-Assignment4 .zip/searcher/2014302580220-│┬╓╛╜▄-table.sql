
CREATE TABLE `2014302580220_professor_info` (
  `name` char(30) NOT NULL,
  `educationBackground` char(255) DEFAULT NULL,
  `researchInterests` varchar(255) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

