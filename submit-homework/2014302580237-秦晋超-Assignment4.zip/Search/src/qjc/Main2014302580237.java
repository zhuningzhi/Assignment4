package qjc;

public class Main2014302580237 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SearchEngine a =new SearchEngine();

		
	}

}
