package qjc;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;



	
	
	
	public class SearchEngine extends JFrame {

		private JButton search=new JButton("Search");
		private JTextField sb = new JTextField();
		private	JTextArea sg= new JTextArea();
		private String[][] tf=new String[26][5];
		
		public  SearchEngine() {
			
			JPanel p=new JPanel();
			p.add(sb);
			p.add(search);
			p.setLayout(new GridLayout(1, 2,5,0));
			setLayout(new BorderLayout(0,5));
			add(p,BorderLayout.NORTH);
			sg.setLineWrap(true);
			sg.setEditable(false);
			JScrollPane JS1 =new JScrollPane(sg);
			JS1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			add(JS1,BorderLayout.CENTER);
			setTitle("SEARCH");
			setSize(600, 400);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setVisible(true);

			search.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					
					String a = sb.getText().toUpperCase();
					
					
			    	String url2 = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456" ;
			    	sg.setText(null);
			    	try{
			    			Class.forName("com.mysql.jdbc.Driver");
			    			Connection con =DriverManager.getConnection(url2,"root","123456") ;
			    			Statement s = con.createStatement()	;
			    			ResultSet rs =s.executeQuery(
			    			"select* from professor_info where upper(educationBackground) like '%"
			    			+a+"%'or "+ "upper(researchInterests) like '%"+a+"%'"
			    					); 
			    			int  i=0;
			    			while (rs.next()) {
			    			String []info= new String[5];	
								info[0]= rs.getString(1);
								info[1]=rs.getString(2);
								info[2]=rs.getString(3);
								info[3]=rs.getString(4);
								info[4]=rs.getString(5);
								getInfo(info,i);
								i++;
							}
			    			sortByTf(tf,a);
							con.close();
							s.close();
							rs.close();
							
			    	}catch(ClassNotFoundException e){
			    		e.printStackTrace();
			    	}catch (SQLException e) {
			    		e.printStackTrace();
					}
					
						
					
				}
			});
			
			
			
			
		}

		public void getInfo(String[] a,int i){
				tf[i] = a;
				
		}
		
		public void sortByTf(String[][] a,String s) {
			int [] x =new int[a.length];
			int w =0;
			for (int i = 0; i < a.length; i++) {
				if (a[i][0]==null) {
					break;
				}
				String str=" "+a[i][2].toUpperCase()+" ";
				String str1=" "+a[i][1].toUpperCase()+" ";
				x[i]= str.split(s).length+str1.split(s).length-2;
				w++;
				
			}
		
			
			int [] y =new int[w];
			int c =0;
			for (int j = 0; j < w; j++) {
				y[j]=j;
			}
			for (int j = 0; j < w; j++) {
			
				for (int k = w; k>j; k--) {
								
					if (x[j]<=x[k]) {
						
						c=x[k];
						x[k]=x[j];
						x[j]=c;
						c=y[j];
						y[j] =y[k];
						y[k]=c;
						
					}
					
				}	
				
			}
			for (int m = 0; m < y.length; m++) {
				
				
				
					sg.append("Professor's Name:"+
						a[y[m]][0]+"\n"+"Professor's Education Background:\n"+
						a[y[m]][1]+"\nProfessor's Research Interests:"+
						a[y[m]][2]+"Professor's Email:"+
						a[y[m]][3]+"\n"+"Professor's Phone:"+
						a[y[m]][4]+"\n\n");
				
				
				
				
				
			}
			
			
			
			
			
			/*
			 * 
			 * sg.append("Professor's Name:"+
					info[0]+"\n"+"Professor's Education Background:\n"+
					info[1]+"\nProfessor's Research Interests:"+
					info[2]+"Professor's Email:"+
					info[3]+"\n"+"Professor's Phone"+
					info[4]+"\n\n");
			*/
			
		}
		
	

	
}
